package com.test;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazonaws.services.lambda.runtime.Context;
public class App {
	
	static final Logger log = LoggerFactory.getLogger(App.class);

	public static String handleRequest(Request request, Context context) {
		if(request.getHttpMethod().equals("GET")){
			String s="Hello"+request.getKeyword();
			return s;
		}
		return null;
	}

}

